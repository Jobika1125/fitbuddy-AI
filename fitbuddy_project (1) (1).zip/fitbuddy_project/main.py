"""AI FitBuddy - run this file (VS Code: press the ▶ button)."""
from fitbuddy.app import App

if __name__ == "__main__":
    App().mainloop()
