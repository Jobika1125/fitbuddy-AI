"""AI FitBuddy package."""
