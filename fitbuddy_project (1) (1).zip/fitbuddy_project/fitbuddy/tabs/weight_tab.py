import tkinter as tk
from tkinter import messagebox, ttk

from ..storage import today


class WeightTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, padding=12)
        self.app = app
        row = ttk.Frame(self)
        row.pack(fill="x")
        ttk.Label(row, text="Today's weight (kg):").pack(side="left")
        self.wt = tk.StringVar()
        ttk.Entry(row, textvariable=self.wt, width=10).pack(side="left", padx=8)
        ttk.Button(row, text="Log", command=self.log).pack(side="left")
        self.lbl = ttk.Label(self)
        self.lbl.pack(pady=6)
        self.cv = tk.Canvas(self, width=580, height=280, bg="white", highlightthickness=1, highlightbackground="#ccc")
        self.cv.pack(pady=6)

    def log(self):
        if not self.app.has_profile():
            return
        try:
            w = float(self.wt.get())
            if w <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("FitBuddy", "Correct weight number podunga.")
            return
        d = self.app.d
        d["weights"] = [x for x in d["weights"] if x["date"] != today()] + [{"date": today(), "kg": w}]
        self.app.p["weight"] = w
        self.wt.set("")
        self.app.save_profile_data()
        self.app.save_data()

    def refresh(self):
        ws = sorted(self.app.d["weights"], key=lambda x: x["date"])
        self.lbl.config(text=f"Total change: {ws[-1]['kg'] - ws[0]['kg']:+.1f} kg" if len(ws) > 1 else "")
        self.cv.delete("all")
        ws = ws[-15:]
        if len(ws) < 2:
            self.cv.create_text(290, 140, text="Rendu ketta athigama weight log pannunga, chart varum 📈", fill="gray")
            return
        lo, hi = min(x["kg"] for x in ws), max(x["kg"] for x in ws)
        span = (hi - lo) or 1
        pts = [(50 + i * 500 / (len(ws) - 1), 240 - (x["kg"] - lo) / span * 190) for i, x in enumerate(ws)]
        self.cv.create_line(*[c for pt in pts for c in pt], fill="#2a7de1", width=2)
        for (x, y), w in zip(pts, ws):
            self.cv.create_oval(x - 4, y - 4, x + 4, y + 4, fill="#2a7de1", outline="")
            self.cv.create_text(x, y - 12, text=f"{w['kg']:.1f}", font=("Segoe UI", 8))
        self.cv.create_text(50, 262, text=ws[0]["date"], font=("Segoe UI", 8))
        self.cv.create_text(550, 262, text=ws[-1]["date"], font=("Segoe UI", 8))
