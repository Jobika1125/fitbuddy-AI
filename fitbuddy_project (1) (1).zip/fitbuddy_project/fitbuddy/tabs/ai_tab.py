import threading
import tkinter as tk
from tkinter import messagebox, ttk

from ..ai_client import ask_claude
from ..storage import ENV_FILE, saved_key


class AITab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, padding=12)
        self.app, self.history = app, []
        row = ttk.Frame(self)
        row.pack(fill="x")
        ttk.Label(row, text="API key:").pack(side="left")
        self.key = tk.StringVar(value=saved_key())
        ttk.Entry(row, textvariable=self.key, show="*", width=40).pack(side="left", padx=6)
        ttk.Button(row, text="Save key", command=self.save_key).pack(side="left")
        self.chat = tk.Text(self, wrap="word", state="disabled", font=("Segoe UI", 10), height=18)
        self.chat.pack(fill="both", expand=True, pady=8)
        self.chat.tag_config("you", foreground="#2a7de1")
        self.chat.tag_config("bot", foreground="#1a8a3c")
        row2 = ttk.Frame(self)
        row2.pack(fill="x")
        self.msg = tk.StringVar()
        e = ttk.Entry(row2, textvariable=self.msg)
        e.pack(side="left", fill="x", expand=True)
        e.bind("<Return>", self.send)
        ttk.Button(row2, text="Send", command=self.send).pack(side="left", padx=6)

    def refresh(self):
        pass

    def save_key(self):
        ENV_FILE.write_text(f"ANTHROPIC_API_KEY={self.key.get().strip()}\n")
        messagebox.showinfo("FitBuddy", "Key saved (.env).")

    def say(self, who, text):
        self.chat.config(state="normal")
        self.chat.insert("end", f"{who}: ", "you" if who == "You" else "bot")
        self.chat.insert("end", text + "\n\n")
        self.chat.config(state="disabled")
        self.chat.see("end")

    def send(self, _event=None):
        q = self.msg.get().strip()
        if not q or not self.app.has_profile():
            return
        key = self.key.get().strip()
        if not key:
            messagebox.showwarning("FitBuddy", "API key podunga (console.anthropic.com).")
            return
        self.msg.set("")
        self.say("You", q)
        self.history.append({"role": "user", "content": q})
        threading.Thread(target=self.worker, args=(key,), daemon=True).start()

    def worker(self, key):
        try:
            reply = ask_claude(key, self.app.p, self.app.d, self.history)
            self.history.append({"role": "assistant", "content": reply})
            self.after(0, self.say, "FitBuddy", reply)
        except Exception as e:
            self.history.pop()
            self.after(0, self.say, "Error", str(e))
