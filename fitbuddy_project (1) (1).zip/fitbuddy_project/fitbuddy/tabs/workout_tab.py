import tkinter as tk
from tkinter import messagebox, ttk

from ..config import PLANS
from ..storage import streak, today


class WorkoutTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, padding=12)
        self.app = app
        self.text = tk.Text(self, wrap="word", state="disabled", height=11, font=("Segoe UI", 11), relief="flat")
        self.text.pack(fill="x")
        self.lbl = ttk.Label(self, font=("Segoe UI", 12, "bold"))
        self.lbl.pack(pady=12)
        ttk.Button(self, text="✅ Inniku workout mudichuten", command=self.log).pack()

    def log(self):
        if not self.app.has_profile():
            return
        if today() in self.app.d["workouts"]:
            messagebox.showinfo("FitBuddy", "Inniku already log pannitteenga ✅")
            return
        self.app.d["workouts"].append(today())
        self.app.save_data()

    def refresh(self):
        w = self.app.d["workouts"]
        self.lbl.config(text=f"🔥 Streak: {streak(w)} day(s) | Total workouts: {len(set(w))}")
        p = self.app.p
        msg = f"Weekly plan ({p['goal']}):\n\n" + "\n".join(" • " + x for x in PLANS[p["goal"]]) if p else ""
        self.text.config(state="normal")
        self.text.delete("1.0", "end")
        self.text.insert("1.0", msg)
        self.text.config(state="disabled")
