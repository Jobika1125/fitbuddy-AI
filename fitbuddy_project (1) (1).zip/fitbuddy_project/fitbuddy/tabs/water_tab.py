from tkinter import ttk

from ..calculator import water_goal
from ..storage import today


class WaterTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, padding=12)
        self.app = app
        self.lbl = ttk.Label(self, font=("Segoe UI", 13, "bold"))
        self.lbl.pack(pady=10)
        self.bar = ttk.Progressbar(self, length=420)
        self.bar.pack(pady=10)
        row = ttk.Frame(self)
        row.pack(pady=10)
        for ml in (150, 250, 500):
            ttk.Button(row, text=f"+{ml} ml", command=lambda m=ml: self.add(m)).pack(side="left", padx=5)
        ttk.Button(row, text="Reset today", command=lambda: self.add(None)).pack(side="left", padx=5)

    def add(self, ml):
        if not self.app.has_profile():
            return
        w = self.app.d["water"]
        w[today()] = 0 if ml is None else w.get(today(), 0) + ml
        self.app.save_data()

    def refresh(self):
        if not self.app.p:
            self.lbl.config(text="Profile save pannunga")
            return
        goal, drunk = water_goal(self.app.p), self.app.d["water"].get(today(), 0)
        self.bar.config(maximum=goal, value=min(drunk, goal))
        self.lbl.config(text=f"💧 {drunk} / {goal:.0f} ml" + ("  🎉 Goal done!" if drunk >= goal else ""))
