import tkinter as tk
from datetime import date
from tkinter import ttk

from ..calculator import bmi_category, calc_targets, protein_goal
from ..config import MEALS, SPLIT


class OverviewTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, padding=12)
        self.app = app
        self.text = tk.Text(self, wrap="word", state="disabled", font=("Segoe UI", 11), relief="flat")
        self.text.pack(fill="both", expand=True)

    def refresh(self):
        p = self.app.p
        if not p:
            msg = "Profile tab la details save pannunga, apram inga ellam varum."
        else:
            bmi, bmr, tdee, target = calc_targets(p)
            lines = [f"Hi {p['name']}! 👋\n", f"BMI: {bmi:.1f} ({bmi_category(bmi)})", f"BMR: {bmr:.0f} kcal/day",
                     f"Maintenance: {tdee:.0f} kcal/day", f"Target ({p['goal']}): {target:.0f} kcal/day",
                     f"Protein goal: ~{protein_goal(p):.0f} g/day\n", "Today's diet suggestion:"]
            idx = date.today().toordinal()
            for meal, share in SPLIT.items():
                opts = MEALS[p["diet"]][meal]
                lines.append(f"  • {meal} (~{target * share:.0f} kcal): {opts[idx % len(opts)]}")
            msg = "\n".join(lines)
        self.text.config(state="normal")
        self.text.delete("1.0", "end")
        self.text.insert("1.0", msg)
        self.text.config(state="disabled")
