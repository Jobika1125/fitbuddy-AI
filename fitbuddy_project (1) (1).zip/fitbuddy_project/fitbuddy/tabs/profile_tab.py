import tkinter as tk
from tkinter import messagebox, ttk

from ..config import ACTIVITY, GOALS


class ProfileTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent, padding=12)
        self.app, self.v = app, {}
        spec = [("name", "Name", None), ("age", "Age", None), ("gender", "Gender (m/f)", ["m", "f"]),
                ("height", "Height (cm)", None), ("weight", "Weight (kg)", None),
                ("activity", "Activity", [a[0] for a in ACTIVITY.values()]),
                ("goal", "Goal", GOALS), ("diet", "Diet", ["veg", "nonveg"])]
        for i, (key, label, opts) in enumerate(spec):
            ttk.Label(self, text=label).grid(row=i, column=0, sticky="w", pady=5)
            self.v[key] = tk.StringVar()
            w = (ttk.Combobox(self, textvariable=self.v[key], values=opts, state="readonly", width=26) if opts
                 else ttk.Entry(self, textvariable=self.v[key], width=29))
            w.grid(row=i, column=1, padx=10, pady=5)
        ttk.Button(self, text="Save profile", command=self.save).grid(row=len(spec), column=1, sticky="e", pady=12)

    def refresh(self):
        p = self.app.p
        vals = {"name": p.get("name", ""), "age": p.get("age", ""), "gender": p.get("gender", "m"),
                "height": p.get("height", ""), "weight": p.get("weight", ""),
                "activity": ACTIVITY[p.get("activity", "2")][0], "goal": p.get("goal", "maintain"),
                "diet": p.get("diet", "veg")}
        for k, val in vals.items():
            self.v[k].set(val)

    def save(self):
        try:
            v = {k: x.get().strip() for k, x in self.v.items()}
            age, height, weight = int(float(v["age"])), float(v["height"]), float(v["weight"])
            if not v["name"] or v["gender"] not in ("m", "f") or min(age, height, weight) <= 0:
                raise ValueError
            act = next(k for k, a in ACTIVITY.items() if a[0] == v["activity"])
        except (ValueError, StopIteration):
            messagebox.showerror("FitBuddy", "Ellaa fields um sariya fill pannunga (numbers positive ah irukkanum).")
            return
        self.app.p = {"name": v["name"], "age": age, "gender": v["gender"], "height": height, "weight": weight,
                      "activity": act, "goal": v["goal"], "diet": v["diet"]}
        self.app.save_profile_data()
        self.app.nb.select(1)
